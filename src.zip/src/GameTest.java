
public class GameTest {
   public static void main(String[] args) throws Exception {
      Game myGame = new Game();
   }
}

